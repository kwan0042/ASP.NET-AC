﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4
{
    internal class Account
    {
        public int accountNumber {get;}
        public string ownerName {get; set;}
        public double balance { get; set; }
        public double monthlyDepositAmount { get; set; }
        public static double monthlyFee =4.0;
        public static double monthlyInterestRate = 0.0025;
        public static double minimumInitialBalance = 1000;
        public static double minimumMonthDeposit { get; } = 50;

        public Account(string ownerNewName, double newBalance, double monthlyDepositAmount)
        {
            Random accNum = new Random();
            this.accountNumber = accNum.Next(90000, 100000);
            this.ownerName = ownerNewName;
            this.balance = newBalance;
            this.monthlyDepositAmount = monthlyDepositAmount;
        }
        public void eachMonth()
        {
            this.balance -= monthlyFee;
            this.balance *= (1 + monthlyInterestRate);
            this.balance += monthlyDepositAmount;
        }

        public void Deposit (double Deposit)
        {
            this.balance += Deposit;
        }

        public void Withdraw (double Withdraw)
        {
            this.balance -= Withdraw;
        }

       
    }
}
