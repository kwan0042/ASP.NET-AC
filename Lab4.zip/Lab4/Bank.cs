﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4
{
    internal class Bank
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the number of months of deposit: ");
            int totalNumOfDeposit = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("");
            string name;
            List<Account> customerList = new List<Account>();
            int initAmount;
            int montDep;
            int i;
            int j;

            
            while (true){

                Console.Write("Enter Customer Name: ");
                name = Console.ReadLine();

                if (name != "")
                {
                    Console.Write("Enter " + name + "'s Initial Deposit Amount (minimum $1,000.00): ");
                    initAmount = Convert.ToInt16(Console.ReadLine());
                    Console.Write("Enter " + name + "'s Monthly Deposit Amount (minimum $50.00): ");
                    montDep = Convert.ToInt16(Console.ReadLine());

                    Account NewAccount = new Account(name, initAmount, montDep);
                    customerList.Add(NewAccount);
                    Console.WriteLine("");
                    
                }
                else
                {
                    break;
                }
                
            }

            for (i = 0; i < totalNumOfDeposit; i++)
            {
                for (j = 0; j < customerList.Count; j++)
                {
                    customerList[j].eachMonth();
                }
            }

            for (i = 0; i < customerList.Count; i++)

            {
                Console.WriteLine("");
                Console.WriteLine("After " + totalNumOfDeposit + " mouth " + customerList[i].ownerName + "'s account (#" + customerList[i].accountNumber + ") , has a balance of : " + Math.Round(customerList[i].balance, 2));
            }
            Console.WriteLine("\nPress any key to complete");
            Console.ReadKey();

        }
    }
}
