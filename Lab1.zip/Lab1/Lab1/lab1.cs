﻿using System;

namespace Lab1
{
    internal class lab1
    {
        static void Main(string[] args)
        {
            //Create a string variable for use later
           int name;

            //Display a prompt to the user
            Console.Write("what is your name?");

            //Cpature the user's reponse
            name = int.Parse(Console.ReadLine());

            //Display a string liiteral combined with the value of the string variable
            //What does the "\n" do?
            Console.Write("Hello " + name + "\n");

            //Wait for the user to press a key
            //Allows us to read what was displayed
            Console.Write("Thank you for run my first lab! Press any key to end the application");
            Console.Read();
        }
    }
}
