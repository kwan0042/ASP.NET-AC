﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3
{
    class Lab3
    {
        static int[] intArray = {17,  166,  288,  324,  531,  792,  946,  157,  276,  441, 533, 355, 228, 879, 100, 421, 23, 490, 259, 227,
                                 216, 317, 161, 4, 352, 463, 420, 513, 194, 299, 25, 32, 11, 943, 748, 336, 973, 483, 897, 396,
                                 10, 42, 334, 744, 945, 97, 47, 835, 269, 480, 651, 725, 953, 677, 112, 265, 28, 358, 119, 784,
                                 220, 62, 216, 364, 256, 117, 867, 968, 749, 586, 371, 221, 437, 374, 575, 669, 354, 678, 314, 450,
                                 808, 182, 138, 360, 585, 970, 787, 3, 889, 418, 191, 36, 193, 629, 295, 840, 339, 181, 230, 150 };


        static void Main(string[] args)
        {
            //Add your code here to complete the steps given in the section 4 of the lab document 
            string answer = "Y";

            Console.WriteLine("The initial unsorted integer array is: \n");
            PrintArray(intArray);

            //Create new array
            int[] newArray = new int[intArray.Length];
            intArray.CopyTo(newArray, 0);

            //Sort the array using bubble sort and print the result
            Console.WriteLine("");
            Console.WriteLine("Bubble sort made " + BubbleSort(newArray) + " swaps to sort this array\n");
            Console.WriteLine("The sorted array is: \n");
            PrintArray(newArray);

            do
            {
                Console.WriteLine("");
                Console.Write("Enter an integer to search: ");
                int linSearchInt = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("");

                //Search an integer using linear search
                int niddleIndex = LinearSearch(intArray, linSearchInt, out int numOfComparison);
                if (niddleIndex == -1)
                {
                    
                    Console.WriteLine("Linear search made " + numOfComparison + " of comparison to find out that "+ linSearchInt + " is not in this unsorted array.");
                }
                else
                {
                    
                    Console.WriteLine("Linear search made " + numOfComparison + " of comparison to find out that " + linSearchInt + " is at index " + niddleIndex + " in this unsorted array.");
                }

                Console.WriteLine("");
                //Search an integer using binary search

                niddleIndex = BinarySearch(newArray, linSearchInt, out int numOfBinComparison);
                if (niddleIndex == -1)
                {
                    Console.WriteLine("Binary search made " + numOfBinComparison + " of comparison to find out that " + linSearchInt + " is not in this sorted array.");
                }
                else
                {
                    Console.WriteLine("Binary search made " + numOfBinComparison + " of comparison to find out that " + linSearchInt + " is at index " + niddleIndex + " in this sorted array.");
                }

                Console.Write("\nDo you want to search another integer (Y/N)? ");
                answer = Console.ReadLine();
                Console.WriteLine("");

                if (answer =="N")
                {
                Console.WriteLine("Press Enter to exit");
                Console.ReadLine();

                }
            } while (answer == "Y");

        }

        //This method returns the index of a given niddle (an int) in the haystack (an int array)
        //by using linear search. It also returns the value of the number of comparison used to 
        //find the given niddle through the reference parameter numOfComparison.
        static int LinearSearch(int[] haystack, int niddle, out int numOfComparison)
        {
            numOfComparison = 0;
            int niddleIndex = -1;

            //Add your code here searching for the niddle in the haystack.
            int hayLength = haystack.Length;
            for (int i = 0; i < hayLength; i++)
            {
                numOfComparison++;
                if (haystack[i] == niddle)
                {
                    niddleIndex = i;
                    return i;
                }
                


            }       
        
            return niddleIndex;
        }


        static int BubbleSort(int[] arr)
        {
            int numOfSwaps = 0;

            //Add your code here to implement the bubble sort to sort the integer array arr.

            for (int i = 0; i <= arr.Length - 2; i++)
            {
                for (int j = 0; j <= arr.Length - 2; j++)
                {
                    if (arr[j] > arr[j + 1])
                    {
                        int t = arr[j + 1];
                        arr[j + 1] = arr[j];
                        arr[j] = t;
                        numOfSwaps++;
                    }
                    
                }
            }

                return numOfSwaps;
        }

        //This method returns the index of a given niddle (an int) in the haystack (an int array)
        //by using binary search. It also returns the value of the number of comparison used to 
        //find the given niddle through the reference parameter numOfComparison.
        static int BinarySearch(int[] haystack, int niddle, out int numOfComparison)
        {
            numOfComparison = 0;
            int niddleIndex = -1;

            //Add your code here to implement the binary search to find the niddle in the haystack.
            //Reference:https://www.c-sharpcorner.com/blogs/binary-search-implementation-using-c-sharp1
            int minNum = 0;
            int maxNum = haystack.Length - 1;
            while (minNum <= maxNum)
            {
                numOfComparison++;
                int mid = (minNum + maxNum) / 2;
                if (niddle == haystack[mid])
                {
                    niddleIndex = mid;
                    break;
                }
                else if (niddle < haystack[mid])
                {
                    maxNum = mid - 1;
                }
                else
                {
                    minNum = mid + 1;
                }
                
            }


            return niddleIndex;
        }

        //This method has been fully implemented. Just use it to print an integer array to the console.
        static void PrintArray(int[] arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                if (i != arr.Length - 1)
                {
                    Console.Write("{0}, ", arr[i]);
                }
                else
                {
                    Console.Write("{0} ", arr[i]);
                }
            }
            Console.WriteLine();
        }

    }
}
