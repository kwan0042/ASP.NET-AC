﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    internal class lab2
    {
        static void Main(string[] args)
        {
            int inputNum = 0;
            int maxNum = 0;
            int minNum = 0;
            int totalNumOfOdd = 0;
            int sumOfOdd = 0;
            double avgOfOdd = 0;
            int totalNumOfEven = 0;
            int sumOfEven = 0;
            double avgOfEven = 0;
            string answer = "Y";

            do
            {
                while (true)
                {
                    Console.Write("Enter a Integer: ");
                    string typeChar = Console.ReadLine();

                    if (string.IsNullOrEmpty(typeChar))
                    {
                        if (sumOfOdd == 0 && sumOfEven == 0)
                        Console.WriteLine("You did not enter any integer");
                        Console.WriteLine("");
                        break;
                    }
                    else
                    {
                        inputNum = Convert.ToInt32(typeChar);
                        if (totalNumOfOdd == 0 && totalNumOfEven == 0)
                        {
                            maxNum = inputNum;
                            minNum = inputNum;
                        }
                        if (inputNum > maxNum)
                        {
                            maxNum = inputNum;
                        }
                        if (inputNum<minNum)
                        {
                            minNum=inputNum;
                        }
                        //Odd
                        if (inputNum % 2 != 0)
                        {
                            totalNumOfOdd = totalNumOfOdd + 1;
                        }
                        if (inputNum % 2 != 0)
                        {
                            sumOfOdd += inputNum;
                        }
                        if (sumOfOdd != 0)
                        {
                            avgOfOdd = (double)sumOfOdd / totalNumOfOdd;
                        }


                        //Even
                        if (inputNum % 2 == 0)
                        {
                            totalNumOfEven = totalNumOfEven + 1;
                        }
                        if (inputNum % 2 == 0)
                        {
                            sumOfEven += inputNum;
                        }
                        if (sumOfEven != 0)
                        {
                            avgOfEven = (double)sumOfEven / totalNumOfEven;
                        }
                    }
                   
                }

                if (totalNumOfOdd ==0 && totalNumOfEven == 0)
                {
                    
                }
                else{
                    Console.WriteLine("The maximun integer you entered is:" + maxNum);
                    Console.WriteLine("The minimun integer you entered is:" + minNum);
                    Console.WriteLine("");
                    Console.WriteLine("The number of odd integer(s) you entered is:" + totalNumOfOdd);
                    Console.WriteLine("The sum of all odd integer(s) you entered is:" + sumOfOdd);
                    Console.WriteLine("The average of all odd integer(s) you entered is:" + avgOfOdd);
                    Console.WriteLine("");
                    Console.WriteLine("The number of even integer(s) you entered is:" + totalNumOfEven);
                    Console.WriteLine("The sum of all even integer(s) you entered is:" + sumOfEven);
                    Console.WriteLine("The average of all even integer(s) you entered is:" + avgOfEven);
                    Console.WriteLine("");
                }
                
                Console.Write("Play again (Y)? = ");
                answer= Console.ReadLine();
                maxNum = 0;
                minNum = 0;
                totalNumOfOdd = 0;
                sumOfOdd = 0;
                avgOfOdd = 0;
                totalNumOfEven = 0;
                sumOfEven = 0;
                avgOfEven = 0;
                Console.WriteLine("");


                if (answer == "n")
                {
                    Console.WriteLine("Thank you for play. Press Enter to finish. Press any key to continue...");
                    Console.ReadLine();
                }
            } while (answer == "y");

            
        
        }
    }
}

       

            
    


